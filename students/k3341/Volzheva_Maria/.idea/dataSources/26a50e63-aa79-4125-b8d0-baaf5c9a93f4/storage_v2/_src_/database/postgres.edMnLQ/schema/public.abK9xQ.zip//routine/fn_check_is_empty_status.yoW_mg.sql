create function fn_check_is_empty_status() returns trigger
    language plpgsql
as
$$
begin    
    if (select distinct seats.is_empty
        from railways.seats, railways.tickets
        where new.seat = seats.seat_id) then return new;
    else 
        return null;
    end if;
end;
$$;

alter function fn_check_is_empty_status() owner to postgres;

